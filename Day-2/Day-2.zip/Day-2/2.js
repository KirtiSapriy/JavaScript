var na = "alice";

na = "bod";

console.log(na);