var a=null;

console.log(typeof a);
