var a = "Alice!";
var b = "Hello,";

console.log(b + a);