var a = 100;

console.log(a);
console.log(typeof a);