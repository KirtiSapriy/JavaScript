var a;

console.log(typeof a);
