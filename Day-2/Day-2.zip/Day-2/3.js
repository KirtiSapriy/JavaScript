const pi = 3.14;

pi = 3.1415;
console.log((pi));
