var pa = 10000;
var r = 10;
var y = 1;

var intrest = pa * r * y / 100;

console.log("(intrest is = " + intrest);