var a;
const pi = 3.14;
var r = 3;

a = 2 * pi * r;

console.log("Perimeter of the circle = " + a);