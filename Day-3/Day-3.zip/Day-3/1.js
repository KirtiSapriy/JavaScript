var a;
const pi = 3.14;
var r = 10;

a = pi * (r * r);

console.log("Area of Circle = "+a);