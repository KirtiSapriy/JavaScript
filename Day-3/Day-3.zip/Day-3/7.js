var basic = 10000;
var alw = 1000;

var totle = basic + alw;

console.log("Total Salary = " + totle);