var base = 5;
var height = 10;

var ans = base * height / 2;

console.log("area of triangle = " + ans)