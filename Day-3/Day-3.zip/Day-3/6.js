var amount = 150;
var tax = 10;



var totle = (amount * tax) / 100;
amount += totle;
console.log(amount);