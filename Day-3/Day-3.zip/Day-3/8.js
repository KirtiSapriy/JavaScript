var a = 5;
var b = 10;

console.log("First Value = " + a);
console.log("Second Value = " + b);

var c = a;
a = b;
b = c;
console.log("after swaping First Value = " + a);
console.log("after swaping Second Value = " + b);
