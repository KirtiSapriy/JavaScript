var length = 4;
var width = 6;

var ans = length * width;

console.log("area of rectangle = "+ans)